var appOpen = document.getElementById('appOpen');
var app = document.getElementById('app');
var pass = document.getElementById('pass');
var errorPass = document.getElementById('error-pass');
errorPass.style.display = 'none';
var loginBtn = document.getElementById('loginBtn');
var getPass = 'alamin';

function loginCheck() {
    if(pass.value == getPass) {
        app.style.display = "block";
        appOpen.style.display = "none";
    } else {
        errorPass.style.display = "block";
        setTimeout(() => {
            errorPass.style.display = "none";
        }, 3000);
    }
}